Item Transition Inspiration
=========

Some inspiration and ideas for item transitions in different scenarios and use cases including a small component, a full-width image header and a product image with a transparent background.

[Article on Codrops](http://tympanus.net/codrops/?p=18632)

[Demo](http://tympanus.net/Development/ItemTransitions/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2013](http://www.codrops.com)